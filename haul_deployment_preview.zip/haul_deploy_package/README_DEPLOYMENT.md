# Haul Marketplace — Deployment package

## Current status
This package can deploy a **public preview** of the Haul Progressive Web App (PWA). It is not yet a production marketplace. Accounts, listings, cart and orders in this version use browser-local demo data and are not shared across users or devices. Do not use it for real payments, sensitive personal information, medical information, or real customer orders.

Owner/admin email intended for the later secured backend: `kajuniorwembeee@gmail.com`. This email is not automatically an admin account just because it appears in the project. Admin authorization must be implemented and tested on the server/database before launch.

## Option A — static host (phone-friendly)
1. Keep all files in this folder together.
2. In a browser, open a static hosting provider that supports uploading a site folder/ZIP (for example Cloudflare Pages Direct Upload).
3. Create a Pages project and upload this folder's contents or a ZIP of the contents.
4. Wait for the host to give you an HTTPS URL.
5. Open that URL in Chrome on Android. Use Chrome menu → Install app or Add to Home screen.

If the host asks you to connect GitHub or use a command line, stop and choose its direct-upload option if available. Do not add payment details or upgrade plans just for this preview.

## Option B — Firebase Hosting (later)
The included `firebase.json` is a hosting configuration file, but deploying through the Firebase CLI normally requires a command-line environment. Firebase Console alone may not deploy these files. Do not upgrade Firebase just because Hosting shows an upgrade prompt; use a free static host for the preview instead.

## Before a real public launch
- Integrate Firebase Authentication in the app (email/password sign-up, sign-in, sign-out, password reset, verified email).
- Replace localStorage demo data with Firestore reads/writes.
- Deploy and test restrictive Firestore security rules; never let users self-assign admin.
- Create and test owner/admin authorization for the verified owner email.
- Add provider verification, abuse reporting, order-state validation, rate limits, privacy policy, terms, support contact, and backups.
- Add real payment/delivery integrations only after secure backend and business/legal requirements are reviewed.
- Test on multiple accounts and devices before inviting real users.
